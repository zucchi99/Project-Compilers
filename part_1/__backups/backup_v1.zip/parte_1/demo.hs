module Main where
import Alex
import Happy

-- Si scriva una funzione toStringTree che dato un albero si ottenga una stringa che lo rappresenti
toStringTree :: (Eq a, Show a) => Tree a -> String
toStringTree (Node (v,h) []) = "Nodo: v: " ++ show v ++ " h: " ++ show h
toStringTree (Node (v,h) xs) = "Nodo: v: " ++ show v ++ " h: " ++ show h ++ " con Figli -> (" ++ (\(x:xs) -> foldl (\acc x -> acc ++ "; " ++ x) x xs) (map toStringTree xs) ++ ")"

-- si scriva un predicato isAlmostBalanced che, preso un albero, determina se ha la seguente proprietà: per ogni nodo le altezze di tutti i figli differiscono al massimo di 1.
isAlmostBalanced :: (Show a) => Tree a -> Bool
isAlmostBalanced (Node (v,h) xs) = ((h - minHeight) < 3) && and (map isAlmostBalanced xs) where
    minHeight = minAux $ map (\(Node (v,h) _) -> h) xs where
        minAux [] = 0
        minAux xs = minimum xs 

test = do 
    let tree0 = parseTreeInt $ alexScanTokens "1"
    let tree1 = parseTreeInt $ alexScanTokens "5{ 1 {2 3{ 4}} 6 {7 }8}"
    let tree2 = parseTreeInt $ alexScanTokens "5{ 1 {2 3{ 4}} 6 {7 }8{1}}"
    let tree3 = parseTreeInt $ alexScanTokens "21{41{65{  4 1 3 {61{ 7 5 6} 53} 7 }} 8}"
    let tree4 = parseTreeInt $ alexScanTokens "1{ 2  {4 5 } 3 {6  7}}"
    let tree5 = parseTreeDouble $ alexScanTokens "1.0"
    let tree6 = parseTreeDouble $ alexScanTokens "5.0{ 1.0 {2.0 3.0{ 4.0}} 6.0 {7.0 }8.0}"
    let tree7 = parseTreeDouble $ alexScanTokens "5.0{ 1.0 {2.0 3.0{ 4.0}} 6.0 {7.0 }8.0{1.0}}"
    let tree8 = parseTreeDouble $ alexScanTokens "21.43{41.89{60.63{  4.62 1.12 3.41 {62.71{ 7.11 5.44 6.14} 53.16} 7.74 }} 5.91}"
    let tree9 = parseTreeDouble $ alexScanTokens "1.876 { 2.456  {4.134 5.968 } 3.91 {6.013  7.987}}"
    print (toStringTree tree0)
    print (toStringTree tree1)
    print (toStringTree tree2)
    print (toStringTree tree3)
    print (toStringTree tree4)
    print (toStringTree tree5)
    print (toStringTree tree6)
    print (toStringTree tree7)
    print (toStringTree tree8)
    print (toStringTree tree9)
    print (isAlmostBalanced tree0)
    print (isAlmostBalanced tree1)
    print (isAlmostBalanced tree2)
    print (isAlmostBalanced tree3)
    print (isAlmostBalanced tree4)
    print (isAlmostBalanced tree5)
    print (isAlmostBalanced tree6)
    print (isAlmostBalanced tree7)
    print (isAlmostBalanced tree8)
    print (isAlmostBalanced tree9)

main = do
    test